# KCC_e-commerce_solution
Web Mini Project
